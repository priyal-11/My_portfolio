const Contact = () => (
    <section id="contact">
      <h2>Contact</h2>
      <p>Email: priyalshah04845@gmail.com</p>
      <p>Phone: +1(336)-521-6549</p>
      <p>LinkedIn | GitHub Profile</p>
    </section>
  );
  
  export default Contact;
  