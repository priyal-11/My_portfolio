import React from 'react';
import './Skills.css'; // Assuming you add your CSS here
import { FaPython, FaDatabase,  FaChartBar, FaToolbox, FaProjectDiagram } from 'react-icons/fa'; // Font Awesome Icons

const Skills = () => (
  <section id="skills" className="skills-section">
    <h2 className="section-title">Skills</h2>
    <div className="skills-grid">
      <div className="skill-card">
        <FaPython className="skill-icon" />
        <h3>Programming Languages</h3>
        <p>Python, SQL, R</p>
      </div>

      <div className="skill-card">
        <FaDatabase className="skill-icon" />
        <h3>Database & Cloud</h3>
        <p>MySQL, MongoDB, Oracle, AWS (Athena, Cloud9, S3 RedShift)</p>
      </div>

      <div className="skill-card">
        <FaChartBar className="skill-icon" />
        <h3>Data Analysis & Manipulation</h3>
        <p>EDA, NLP, Pandas, NumPy, Scikit-learn</p>
      </div>

      <div className="skill-card">
        <FaProjectDiagram className="skill-icon" />
        <h3>Data Visualization</h3>
        <p>Tableau, PowerBI, Plotly, Seaborn, matplotlib, Streamlit</p>
      </div>

      <div className="skill-card">
        <FaToolbox className="skill-icon" />
        <h3>Tools</h3>
        <p>Git/GitHub, Jupyter Hub, Google Colab, VS Code, MS Excel, APIs</p>
      </div>

      <div className="skill-card">
        <FaProjectDiagram className="skill-icon" />
        <h3>Agile Methodologies</h3>
        <p>SDLC, SCRUM</p>
      </div>
    </div>
  </section>
);

export default Skills;
